<!--This javascript file adds some features to our home page-->


function enlarge(i)
{
var x=document.getElementsByClassName("image1");
x[i].style.width="160px";
x[i].style.height="160px";
}

function reduce(i)
{
var x=document.getElementsByClassName("image1");
x[i].style.width="150px";
x[i].style.height="150px";
}